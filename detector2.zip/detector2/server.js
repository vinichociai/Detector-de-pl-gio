const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');

const app = express();
const PORT = 3000;

// Configurar o uso do Body-Parser
app.use(bodyParser.json());

// Rota para verificar plágio
app.post('/check-plagiarism', async (req, res) => {
    const { text } = req.body;

    if (!text) {
        return res.status(400).json({ error: 'Texto não pode estar vazio.' });
    }

    try {
        // Opções para a requisição da API
        const options = {
            method: 'POST',
            url: 'https://plagiarism-checker-and-auto-citation-generator-multi-lingual.p.rapidapi.com/plagiarism',
            headers: {
                'x-rapidapi-key': '#', // Substitua por sua chave do RapidAPI
                'x-rapidapi-host': 'plagiarism-checker-and-auto-citation-generator-multi-lingual.p.rapidapi.com',
                'Content-Type': 'application/json'
            },
            data: {
                text: text,
                language: 'en', // Substitua pelo idioma apropriado, se necessário
                includeCitations: false,
                scrapeSources: false
            }
        };

        // Faz a requisição para a API
        const response = await axios.request(options);
        console.log('Resposta da API:', response.data);

        // Envia a resposta para o frontend
        res.status(200).json(response.data);
    } catch (error) {
        console.error('Erro ao conectar com a API:', error.response?.data || error.message);
        res.status(500).json({
            error: 'Erro ao processar a análise.',
            details: error.response?.data || error.message
        });
    }
});

// Servir arquivos estáticos
app.use(express.static('public'));

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
