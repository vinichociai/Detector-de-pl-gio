document.querySelector('.botao').addEventListener('click', async () => {
    console.log("Botão clicado");
    const texto = document.querySelector('.caixa_txt').value.trim();
    const loadingElement = document.getElementById('loading');
    const resultadoElement = document.getElementById('resultado');

    if (!texto) {
        alert("Por favor, insira um texto para análise.");
        return;
    }

    // Limpa o resultado e exibe o ícone de carregamento
    resultadoElement.innerHTML = "";
    loadingElement.style.display = "block";

    try {
        const response = await fetch('/check-plagiarism', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: texto })
        });

        if (response.ok) {
            const result = await response.json();
            loadingElement.style.display = "none"; // Esconde o ícone de carregamento

            // Exibe o resultado da API
            resultadoElement.innerHTML = `<p>Resultado da análise: <strong>${result.percentPlagiarized || 0}% de plágio</strong></p>`;
        } else {
            loadingElement.style.display = "none"; // Esconde o ícone de carregamento
            const error = await response.json();
            resultadoElement.innerHTML = `<p style="color: red;">Erro: ${error.error}</p>`;
        }
    } catch (error) {
        console.error('Erro ao conectar com o servidor:', error);
        loadingElement.style.display = "none";
        resultadoElement.innerHTML = `<p style="color: red;">Erro ao conectar com o servidor.</p>`;
    }
});
